// File:        linkedlist.h
// Author:      Geoffrey Tien
// Date:        2016-05-24
// Description: Declaration of private helper functions for the LinkedList class
//              Leave this blank if you have no private functions to declare

// Declaration only, implement your functions in linkedlist.cpp
// e.g.
// void MyHelper(int someval);