// File:        rbtreeprivate.h
// Author:      Geoffrey Tien
// Date:        2016-06-05
// Description: Declaration of private helper functions for the RBTree class
//              Leave this blank if you have no private functions to declare

// Declaration only, implement your functions in rbtree.cpp
// e.g.
// void MyHelper(int someval);

